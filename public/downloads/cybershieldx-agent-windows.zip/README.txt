CyberShieldX Windows Agent
=======================

Installation Instructions:
1. Extract this ZIP file
2. Run install.bat as administrator
3. Follow the on-screen instructions

Prerequisites:
- Windows 7/8/10/11
- Node.js installed (download from https://nodejs.org if not installed)
- NSSM - the Non-Sucking Service Manager (download from http://nssm.cc if not installed)

For more information, see the full manual at https://cybershieldx.be/docs

For support, contact: support@cybershieldx.be
